/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'ro', {
	ltr: 'Direcția textului de la stânga la dreapta',
	rtl: 'Direcția textului de la dreapta la stânga'
} );
