/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'zh-cn', {
	ltr: '文字方向为从左至右',
	rtl: '文字方向为从右至左'
} );
